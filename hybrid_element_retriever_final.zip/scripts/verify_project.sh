#!/usr/bin/env bash
set -euo pipefail

echo "Running formatting checks (black)..."
black --check src/her tests

echo "Running flake8..."
flake8 src/her tests

echo "Running mypy..."
mypy src/her

echo "Running pytest..."
pytest --cov=src/her --cov-report=term

echo "All checks passed."