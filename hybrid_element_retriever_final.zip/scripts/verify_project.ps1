Param()

Write-Output "Running formatting checks (black)..."
black --check src/her tests

Write-Output "Running flake8..."
flake8 src/her tests

Write-Output "Running mypy..."
mypy src/her

Write-Output "Running pytest..."
pytest --cov=src/her --cov-report=term

Write-Output "All checks passed."