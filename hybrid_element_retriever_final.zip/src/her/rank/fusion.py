"""Late fusion ranking of element candidates.

This module combines semantic similarity scores with heuristic scores to
produce a final ranking.  It also applies a simple transformation to
generate CSS selectors for the elements.  In a real system you'd support
multiple locator strategies and incorporate promotion of previously
successful locators.
"""

from __future__ import annotations

from typing import List, Dict, Any

import numpy as np

from ..config import HERConfig
from .heuristics import compute_heuristic_score


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
        return 0.0
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


def rank_candidates(
    phrase: str,
    elements: List[Dict[str, Any]],
    query_vec: np.ndarray,
    element_vecs: List[np.ndarray],
    config: HERConfig,
) -> List[Dict[str, Any]]:
    """Rank element descriptors by semantic and heuristic relevance.

    Args:
        phrase: The query phrase.
        elements: A list of element descriptor dicts.
        query_vec: The embedding for the phrase.
        element_vecs: Embeddings for the elements.
        config: Configuration containing weights.

    Returns:
        A list of dictionaries representing ranked candidates.  Each
        dictionary has keys ``type``, ``selector``, ``score`` and ``stability``.
    """
    candidates: List[Dict[str, Any]] = []
    for element, emb in zip(elements, element_vecs):
        sim = cosine_similarity(query_vec, emb)
        heur = compute_heuristic_score(phrase, element)
        score = config.alpha * sim + config.beta * heur
        selector = f"{element.get('tag')}[backendNodeId='{element.get('backendNodeId')}']"
        candidates.append({
            "type": "css",
            "selector": selector,
            "score": score,
            "stability": heur,
            "rationale": f"sim={sim:.2f}, heur={heur:.2f}",
        })
    # sort by score descending
    candidates.sort(key=lambda c: c["score"], reverse=True)
    # return top K
    return candidates[:config.k]
