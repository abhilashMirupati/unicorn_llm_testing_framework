"""Chromium DevTools Protocol bridge.

This module encapsulates calls to the Chrome DevTools Protocol (CDP) to
retrieve the flattened DOM and full accessibility tree.  These functions
operate on an existing Playwright page object and synchronously return
structured data.  It is the responsibility of the caller to ensure that
the page is fully loaded before invoking these functions.
"""

from typing import Any, Dict, List

from playwright.sync_api import Page


def get_flattened_document(page: Page, *, pierce: bool = True) -> List[Dict[str, Any]]:
    """Return a flattened representation of the DOM for the given page.

    This function uses the DevTools protocol `DOM.getFlattenedDocument` to
    obtain a flattened list of node dictionaries.  The `pierce` argument
    instructs the browser to pierce shadow DOM boundaries.

    Args:
        page: The Playwright :class:`Page` from which to obtain the DOM.
        pierce: Whether to pierce shadow DOM boundaries.

    Returns:
        A list of node dictionaries as returned by the CDP.
    """
    session = page.context.new_cdp_session(page)
    result: Dict[str, Any] = session.send(
        "DOM.getFlattenedDocument", {"pierce": pierce}
    )
    # The result dictionary contains a ``nodes`` list when successful.
    return result.get("nodes", [])


def get_full_ax_tree(page: Page) -> List[Dict[str, Any]]:
    """Return the full accessibility tree for the given page.

    This function calls the DevTools protocol `Accessibility.getFullAXTree` to
    retrieve a complete accessibility tree snapshot.  Each entry in the
    returned list corresponds to an accessibility node and includes
    properties such as role, name and location.

    Args:
        page: The Playwright :class:`Page` for which to retrieve the AX tree.

    Returns:
        A list of AX node dictionaries.
    """
    session = page.context.new_cdp_session(page)
    result: Dict[str, Any] = session.send("Accessibility.getFullAXTree")
    return result.get("nodes", [])
