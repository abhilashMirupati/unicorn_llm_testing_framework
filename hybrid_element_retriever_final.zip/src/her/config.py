"""Configuration models and defaults for the Hybrid Element Retriever.

The framework uses a small set of configurable parameters to control
timeouts, thresholds and ranking weights.  You can load configurations
from a YAML file or pass them directly to the :class:`HybridClient`.

"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class HERConfig:
    """Configuration options for the Hybrid Element Retriever.

    The defaults are suitable for most use cases.  You can override
    individual values when constructing a :class:`HybridClient`.
    """

    dom_max_wait_ms: int = 10_000
    network_idle_ms: int = 1_000
    ax_presence_timeout_ms: int = 3_000
    k: int = 20
    alpha: float = 1.0  # weight for semantic similarity
    beta: float = 0.5   # weight for heuristic scores
    gamma: float = 0.2  # weight for promotion/previous winners
    auto_index: bool = True
    dom_hash_delta_threshold: float = 0.10
    logging_level: str = "INFO"
    deterministic_seed: Optional[int] = None

    # Additional configuration can be stored in this dictionary
    extra: Dict[str, Any] = field(default_factory=dict)


DEFAULT_CONFIG = HERConfig()
