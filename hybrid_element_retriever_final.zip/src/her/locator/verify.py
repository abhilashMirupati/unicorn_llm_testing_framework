"""Locator verification utilities.

These functions would normally verify that a locator uniquely identifies
an element and perform occlusion/visibility checks.  The current
implementation is a no‑op.
"""

from typing import Any


def verify_locator(locator: Any) -> bool:
    """Return True for all locators in the stub implementation."""
    return True
