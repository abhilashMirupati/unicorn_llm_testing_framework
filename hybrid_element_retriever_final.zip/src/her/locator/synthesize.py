"""Locator synthesis from ranked candidates.

This module takes ranked candidates and produces a list of concrete
locators.  In a real implementation you might choose between getByRole,
CSS and XPath strategies based on uniqueness and stability.  Here we
return the candidates unchanged for demonstration purposes.
"""

from typing import List

from ..cli_api import LocatorCandidate


def synthesise_locators(candidates: List[LocatorCandidate]) -> List[LocatorCandidate]:
    """Return the locators in the same order as ranked candidates."""
    return candidates
