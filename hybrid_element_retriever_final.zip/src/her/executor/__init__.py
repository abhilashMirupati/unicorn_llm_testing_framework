"""Action execution subsystem."""
