"""Vector database integration layer."""
