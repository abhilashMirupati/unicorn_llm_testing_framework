"""Session management subpackage.

The session manager coordinates navigation, automatic indexing and element
inventory caching.  See :mod:`manager` for the primary class.
"""
