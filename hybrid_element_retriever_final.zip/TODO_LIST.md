# TODO List

This file tracks high‑level tasks required to deliver the Hybrid Element Retriever according to the specification.  Each task is accompanied by a checkbox indicating whether it has been completed.

## Repository Structure

- [x] Create the standard project structure with `src/`, `tests/`, `samples/`, `docs/` and `ci/` directories.
- [x] Add packaging files (`pyproject.toml`, `setup.cfg`) with metadata and dependencies.
- [x] Add a `.gitignore` to exclude build artefacts and IDE files.
- [x] Provide a license (MIT).

## Core Implementation

- [x] Implement a lightweight intent parser capable of extracting actions and target phrases.
- [x] Stub out the session manager with automatic indexing behaviour and a simple element inventory.
- [x] Define element descriptor data classes.
- [x] Stub out embeddings for queries and elements using deterministic hash functions.
- [x] Implement simple ranking with semantic + heuristic fusion.
- [x] Provide a synthesiser that returns the ranked candidates unchanged.
- [x] Stub out action execution that always succeeds when a locator is provided.
- [x] Provide placeholder self‑healing and promotion modules.
- [x] Implement a minimal vector store for embedding caching.

## Public API & CLI

- [x] Expose a `HybridClient` with `act()` and `query()` methods that handle automatic indexing.
- [x] Implement a CLI under `her.cli` that calls these methods and prints JSON output.
- [x] Avoid exposing manual indexing to end users; include an `index()` method only for power users.

## Samples & Tests

- [x] Add a sample site and HTML page to demonstrate overlay handling.
- [x] Write a comprehensive (stubbed) test suite covering the parser, session manager, ranking, self‑healing and end‑to‑end flows.
- [x] Ensure tests run quickly and do not require external browsers.

## Documentation

- [x] Write a user‑friendly README explaining how to install and use the package.
- [x] Document the architecture and pipeline in `docs/ARCHITECTURE.md`.
- [x] Include diagrams in `docs/DIAGRAMS.md` using Mermaid syntax.

## Continuous Integration

- [x] Configure GitHub Actions to run linting, type checking, tests and packaging.
- [x] Provide `scripts/verify_project.sh` and PowerShell equivalent for local checks.

## Self‑Critique

- [x] Provide `SELFCRITIQUE_BEFORE.md` outlining how the implementation matches the specification and where it falls short.
- [x] Provide `SELFCRITIQUE_AFTER.md` describing improvements made and any remaining gaps.

## Packaging & Publishing

- [x] Ensure the project builds a wheel and sdist.
- [ ] Create a thin Java wrapper and Maven template for the Java API (out of scope for stub).
