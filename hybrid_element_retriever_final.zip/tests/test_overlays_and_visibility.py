from her.cli_api import HybridClient


def test_overlay_events_logged() -> None:
    client = HybridClient()
    # For the stub implementation no overlays are detected, so overlay_events is empty
    result = client.act("Click the login button", url="http://example.com")
    assert "overlay_events" in result
    assert isinstance(result["overlay_events"], list)