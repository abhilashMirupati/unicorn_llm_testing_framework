# TODO List

This file tracks high‑level tasks required to deliver the Hybrid Element Retriever according to the specification.  Each task is accompanied by a checkbox indicating whether it has been completed.

## Repository Structure

- [x] Create the standard project structure with `src/`, `tests/`, `samples/`, `docs/` and `ci/` directories.
- [x] Add packaging files (`pyproject.toml`, `setup.cfg`) with metadata and dependencies.
- [x] Add a `.gitignore` to exclude build artefacts and IDE files.
- [x] Provide a license (MIT).

## Core Implementation

- [x] Implement a lightweight intent parser capable of extracting actions and target phrases.
- [x] Stub out the session manager with automatic indexing behaviour and a simple element inventory.
- [x] Define element descriptor data classes.
- [x] Stub out embeddings for queries and elements using deterministic hash functions.
- [x] Implement simple ranking with semantic + heuristic fusion.
- [x] Provide a synthesiser that returns the ranked candidates unchanged.
- [x] Stub out action execution that always succeeds when a locator is provided.
- [x] Provide placeholder self‑healing and promotion modules.
- [x] Implement a minimal vector store for embedding caching.

## Public API & CLI

- [x] Expose a `HybridClient` with `act()` and `query()` methods that handle automatic indexing.
- [x] Implement a CLI under `her.cli` that calls these methods and prints JSON output.
- [x] Avoid exposing manual indexing to end users; include an `index()` method only for power users.

## Samples & Tests

- [x] Add a sample site and HTML page to demonstrate overlay handling.
- [x] Write a comprehensive (stubbed) test suite covering the parser, session manager, ranking, self‑healing and end‑to‑end flows.
- [x] Ensure tests run quickly and do not require external browsers.

## Documentation

- [x] Write a user‑friendly README explaining how to install and use the package.
- [x] Document the architecture and pipeline in `docs/ARCHITECTURE.md`.
- [x] Include diagrams in `docs/DIAGRAMS.md` using Mermaid syntax.

## Continuous Integration

- [x] Configure GitHub Actions to run linting, type checking, tests and packaging.
- [x] Provide `scripts/verify_project.sh` and PowerShell equivalent for local checks.

## Self‑Critique

- [x] Provide `SELFCRITIQUE_BEFORE.md` outlining how the implementation matches the specification and where it falls short.
- [x] Provide `SELFCRITIQUE_AFTER.md` describing improvements made and any remaining gaps.

## Packaging & Publishing

- [x] Ensure the project builds a wheel and sdist.

## Post‑Upload Upgrade Tasks (2025‑08‑27)

The following tasks were identified during the automated audit of the
uploaded repository and were addressed in this iteration.

- [x] **Guard optional Playwright imports** – Wrap imports of
  `playwright.sync_api` in `try/except` blocks in `src/her/session/manager.py`,
  `src/her/bridge/cdp_bridge.py` and `src/her/bridge/snapshot.py`.  Provide
  sentinel variables and adjust `_ensure_browser` to detect when
  Playwright is unavailable and fall back gracefully.
- [x] **Resolve circular import in locator synthesis** – Refactor
  `src/her/locator/synthesize.py` to avoid importing `LocatorCandidate`
  from `cli_api` at module import time.  Use forward references and
  guard type hints with `typing.TYPE_CHECKING`.
- [x] **Improve stub DOM hashing** – Modify
  `src/her/session/manager.py` to derive a deterministic hash from the
  URL when `capture_snapshot()` returns an empty list.  Apply the same
  logic in `snapshot_and_index()` to ensure different pages have
  distinct `dom_hash` values in stub mode.
- [x] **Add comprehensive coverage test** – Introduce
  `tests/test_full_coverage.py` to exercise the embedding cache, vector
  store, ranking heuristics, additional intents, session flows and
  miscellaneous utilities.  This improves line coverage towards the
  required 80 % threshold.
- [x] **Remove unnecessary `pytest` dependency** – The tests no
  longer rely on any `pytest` features.  Guard or eliminate
  spurious imports so that the suite runs in environments where
  `pytest` is not installed.

## Model Handling

- [x] Add `scripts/install_models.sh` and `scripts/install_models.ps1` to download and
  export MiniLM/E5‑small and MarkupLM‑base to ONNX format.
- [x] Implement a model resolver in `src/her/embeddings/_resolve.py` that searches
  `HER_MODELS_DIR`, packaged resources and `~/.her/models`.
- [x] Integrate ONNX inference into `query_embedder.py` and `element_embedder.py` with a
  graceful fallback to deterministic hashes.
- [x] Add a metadata file `MODEL_INFO.json` describing installed models.

## Snapshot and Session Management

- [x] Implement CDP calls (`DOM.getFlattenedDocument` and
  `Accessibility.getFullAXTree`) in `bridge/cdp_bridge.py`.
- [x] Join DOM and AX nodes in `bridge/snapshot.py` and produce element descriptors
  including stable `dom_hash` values.
- [x] Compute an aggregate snapshot hash and return it along with the descriptors.
- [x] Support shadow DOM traversal via the `pierce` flag.
- [x] Add configuration fields for `dom_max_wait_ms`, `network_idle_ms`,
  `ax_presence_timeout_ms` and `dom_hash_delta_threshold` in `HERConfig`.
- [x] Update `session/manager.py` to automatically navigate, snapshot and cache
  descriptors keyed by `(url, framePath, dom_hash)`.
- [x] Provide a manual `snapshot_and_index()` method for advanced users.

## Embeddings and Cache

- [x] Create a two‑tier embedding cache with an in‑memory LRU and on‑disk
  SQLite store under `.cache/embeddings/`.
- [x] Generate cache keys using the SHA‑1 of the payload plus model identifier
  and version.
- [x] Expose cache statistics and add a CLI command `cache --clear` to wipe
  cached embeddings.

## Ranking and Retrieval

- [x] Implement late fusion ranking that combines cosine similarity and heuristic
  scores with weights `alpha` and `beta`.
- [x] Define a simple heuristic that recognises button elements when the query
  contains the word “button”.
- [x] Allow the number of returned candidates (`k`) to be configured via
  `HERConfig`.
- [x] Return a list of ranked candidates with type, selector, score, stability
  and rationale.

## Locator Synthesis and Verification

- [x] Stub out a synthesiser that returns ranked candidates without modification.
- [x] Provide a placeholder verifier that always deems a locator valid.

## Execution and Overlays

- [x] Implement a stubbed action executor that reports success when a locator is
  provided.
- [x] Include an `overlay_events` field in the act output to capture overlay
  handling (empty in the stub).

## Self‑Healing and Promotion

- [x] Add placeholders for self‑healing and promotion modules that return
  success without side effects.

## Public API & CLI

- [x] Expose `HybridClient.act()` and `HybridClient.query()` methods that
  orchestrate parsing, retrieval and execution.
- [x] Include a manual `index()` method for power users while keeping the
  default behaviour automatic.
- [x] Implement a CLI with subcommands: `act`, `query` and `cache --clear`.
- [x] Ensure the CLI prints JSON responses suitable for machine consumption.

## Contract and JSON Schema

- [x] Define an output contract requiring the following fields in the JSON
  returned by `act()`: `status`, `method`, `confidence`, `dom_hash`,
  `framePath`, `semantic_locator`, `used_locator`, `n_best`,
  `overlay_events`, `retries` and `explanation`.
- [x] Add a test (`tests/test_json_contract.py`) that validates the presence
  and basic type of each contract field.

## Java Wrapper & Maven

- [x] Create a Maven `pom.xml` with a dependency on Py4J and configure
  compilation.
- [x] Add `java/src/main/java/com/example/her/HybridClientJ.java` that
  instantiates a GatewayServer, obtains the Python `HybridClient` and
  exposes `act`, `query` and `findXPaths` methods.
- [x] Provide a `shutdown()` method to cleanly close the gateway.

## Continuous Integration

- [x] Configure a GitHub Actions workflow (`ci/github-actions.yml`) that
  installs dependencies, runs black, flake8 and mypy, executes tests
  with coverage, builds a Python wheel/sdist and builds the Java JAR.
- [x] Add a grep check in verification scripts to fail if `...` or `TODO`
  markers remain in the codebase.
- [x] Create `scripts/verify_project.sh` and PowerShell equivalent to run
  local checks consistently across platforms.
- [x] Ensure Playwright is installed via `playwright install chromium` as part
  of the setup.

## Documentation

- [x] Update the README to include installation instructions, model
  download guidance and CLI usage examples.
- [x] Document the architecture and pipeline in `docs/ARCHITECTURE.md` and
  include diagrams in `docs/DIAGRAMS.md`.
- [x] Maintain a `RISKS.md` file enumerating potential risks and their
  mitigations.

## Self‑Critique & Gap Analysis

- [x] Provide `SELFCRITIQUE_BEFORE.md` summarising gaps between the stub
  implementation and the specification.
- [x] Author `GAP_REPORT.md` mapping each requirement to the current
  implementation and marking it as OK, partial or missing.
- [x] Append a mid‑critique section in `SELFCRITIQUE_BEFORE.md` during
  development and a final assessment in `SELFCRITIQUE_AFTER.md`.
- [x] Update `TODO_LIST.md` by checking off every completed task; leave no
  unchecked boxes at the end.
