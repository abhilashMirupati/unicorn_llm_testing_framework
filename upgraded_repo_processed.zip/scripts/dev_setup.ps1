Param()

Write-Output "Installing Playwright browsers…"
npx playwright install chromium

Write-Output "Playwright installation complete."