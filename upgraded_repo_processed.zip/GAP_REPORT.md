# Gap Report

This report compares the specification of the Hybrid Element Retriever (HER) with
the current codebase.  For each major requirement we identify which files
implement it and whether the implementation is **OK**, **partial** or
**missing**.

## Repository structure

* **Standard directories** — The project contains the expected `src/`,
  `tests/`, `docs/`, `scripts/`, `java/` and `ci/` directories.  Packaging
  files (`pyproject.toml`, `setup.cfg`), `CHANGELOG.md`, a licence and a
  `.gitignore` are present (**OK**).

* **No placeholders** — A pre‑commit/CI hook added in `scripts/verify_project.sh`
  and its PowerShell equivalent fails the build if any ellipsis (`...`) or
  `TODO` markers remain.  All source files were audited to remove such
  placeholders (**OK**).

## Models and embeddings

* **Model download scripts** — `scripts/install_models.sh` and
  `scripts/install_models.ps1` install export tools and convert
  `intfloat/e5-small` and `microsoft/markuplm-base` into ONNX format.  The
  models are stored under `src/her/models` and a `MODEL_INFO.json` is
  generated.  These scripts conform to the specification (**OK**).

* **Model resolver** — The helper in `src/her/embeddings/_resolve.py` looks
  for models in the directory specified by `HER_MODELS_DIR`, packaged
  resources (`her.models/<subdir>`) and finally `~/.her/models/<subdir>`.
  It raises a `FileNotFoundError` if none exist (**OK**).

* **Embedders** — `src/her/embeddings/query_embedder.py` and
  `src/her/embeddings/element_embedder.py` attempt to load the E5‑small and
  MarkupLM models via the resolver and onnxruntime.  When unavailable they
  fall back to deterministic SHA‑1–based vectors.  ONNX inference and
  tokenisation are partially implemented; features such as batching and
  proper attention masking are not yet present (**partial**).

* **Embedding cache** — `src/her/embeddings/cache.py` implements a two‑tier
  cache: an in‑memory LRU and a persistent SQLite store.  Vectors are keyed
  by a digest plus model identifier and version, and stored as binary
  blobs.  Cache hit/miss statistics are exposed and a CLI command to clear
  the cache is available (**OK**).

## Snapshotting and session management

* **CDP snapshot** — `src/her/bridge/cdp_bridge.py` calls
  `DOM.getFlattenedDocument` with `pierce=true` and
  `Accessibility.getFullAXTree`.  In `src/her/bridge/snapshot.py` these
  structures are joined via the backend node identifiers.  The snapshot
  returns a list of descriptor dictionaries and a combined DOM hash.  Only a
  subset of the descriptor fields (tag, type, id, classes, aria, labels,
  AX role/name/hidden/disabled, dom_hash) is populated; bounding boxes,
  visibility and neighbours are not yet filled (**partial**).

* **Frames and shadow DOM** — The snapshot uses `pierce=true` for shadow
  DOM traversal but assumes a single frame with a fixed `framePath` of
  `"main"`.  Multi‑frame indexing and per‑frame scoping are not yet
  implemented (**partial**).

* **DOM hash and delta indexing** — Each descriptor includes a stable
  `dom_hash` derived from its tag, id, classes and AX metadata.  The
  combined snapshot hash is the SHA‑1 of all per‑element hashes.  The
  session manager in `src/her/session/manager.py` compares snapshot hashes
  to decide when to re‑index.  A configurable delta threshold is defined in
  `HERConfig` but not yet applied (**partial**).

* **Automatic indexing** — `SessionManager.ensure_page()` navigates to a
  URL when necessary, captures a snapshot and caches descriptors keyed by
  `(url, framePath, dom_hash)`.  The default configuration sets
  `auto_index=True`, so callers never need to invoke `index()` manually
  (**OK**).

## Ranking, locator synthesis and execution

* **Late fusion ranking** — The function `rank_candidates()` in
  `src/her/rank/fusion.py` combines cosine similarity and a heuristic score
  with weights α and β.  A promotion weight γ is defined in the
  configuration but currently unused.  Promotion and tie‑breaking logic are
  not yet implemented (**partial**).

* **Heuristics** — `src/her/rank/heuristics.py` provides a trivial heuristic
  that rewards buttons when the phrase contains the word “button”.  It does
  not consider roles, names, placeholders or visibility attributes as
  required by the spec (**missing**).

* **Locator synthesis** — The synthesiser in `src/her/locator/synthesize.py`
  simply returns ranked candidates unchanged.  It does not attempt to
  generate locators in a semantic‑first order (getByRole → attribute‑based
  CSS → context‑aware XPath) nor verify uniqueness (**missing**).

* **Execution and overlays** — `src/her/executor/actions.py` simulates
  successful actions without interacting with a browser.  There is no
  scrolling, occlusion checking or overlay dismissal.  Overlay events and
  retries are returned as empty lists/dictionaries (**missing**).

* **Self‑healing and promotion** — `src/her/recovery/self_heal.py` and
  `src/her/recovery/promotion.py` are placeholders that return success but
  do not try alternate locators or persist promotions (**missing**).

## Public APIs, CLI and contract

* **HybridClient API** — The class in `src/her/cli_api.py` exposes
  `act()` and `query()` methods and hides manual indexing by default.  A
  convenience method `index()` is available for advanced users.  The
  methods return JSON‑serialisable dictionaries containing status,
  confidence, DOM hash, frame path, a semantic locator, the used locator,
  an `n_best` list, overlay events, retries and an explanation.  A new
  test (`tests/test_json_contract.py`) verifies that all contract fields
  are present and non‑empty (**OK**).

* **CLI** — `src/her/cli.py` uses `argparse` to implement subcommands
  `act`, `query` and `cache --clear`, printing JSON responses.  The CLI
  instantiates a `HybridClient` and honours the automatic indexing
  behaviour (**OK**).

* **Java wrapper** — `java/pom.xml` defines a Maven project that depends
  on Py4J and produces a JAR.  `java/src/main/java/com/example/her/HybridClientJ.java`
  wraps the Python client via a GatewayServer and exposes `act`, `query`
  and `findXPaths` methods.  The wrapper is thin and defers all logic
  to Python (**OK**).

## Tests and continuous integration

* **Test suite** — The `tests/` directory includes unit tests for
  intent parsing, ranking, session auto‑indexing, overlay handling,
  self‑healing and end‑to‑end flows.  A new contract test asserts that the
  JSON output from `HybridClient.act()` conforms to the required schema.
  Coverage instrumentation is enabled via pytest‑cov.  Tests for frames,
  shadow DOM, overlays, caching hits/misses and promotion have yet to be
  written (**partial**).

* **CI workflow** — `ci/github-actions.yml` installs dependencies,
  performs formatting and lint checks (black/flake8), runs mypy in strict
  mode, executes tests with coverage and builds wheel/sdist and a Java
  JAR.  The workflow currently targets Python 3.9 on Ubuntu.  Future work
  should extend the matrix to Python 3.9–3.12 on both Ubuntu and Windows
  and upload build artifacts.  A grep check forbids leaving `...` or
  `TODO` placeholders in the code (**partial**).

## Summary

The upgraded repository satisfies many of the structural and packaging
requirements set out in the HER specification: it includes model download
scripts, a model resolver, two‑tier caching, automatic indexing and a
thin Java wrapper.  Several features remain stubbed or only partially
implemented.  In particular, advanced heuristics, robust locator
synthesis, real browser execution, self‑healing and promotion logic, and
expanded CI coverage are incomplete.  These areas should be prioritised in
future development to fully align with the specification.