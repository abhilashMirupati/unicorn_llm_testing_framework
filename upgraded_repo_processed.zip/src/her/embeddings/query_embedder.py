"""Query embedder for user phrases.

This class converts a user phrase into a vector.  The current
implementation uses a trivial hashing technique to generate a pseudo
vector.  In a real system you would load a small transformer model
(e.g. MiniLM/E5) and perform inference on CPU.
"""

from typing import List, Optional

import os
import numpy as np

from ..utils import sha1_of
from .cache import EmbeddingCache

# Try to import optional dependencies for ONNX inference.  If these are
# unavailable at runtime the embedder will gracefully fall back to a
# deterministic hash‑based implementation.
try:
    import onnxruntime as _ort  # type: ignore
    from transformers import AutoTokenizer  # type: ignore
except Exception:
    _ort = None  # type: ignore
    AutoTokenizer = None  # type: ignore

# Import the model resolver lazily to avoid circular imports during package
# initialisation.  If the resolver cannot be imported the embedder will
# not attempt to load ONNX models.
try:
    from ._resolve import resolve_model_path  # type: ignore
except Exception:
    resolve_model_path = None  # type: ignore


class QueryEmbedder:
    """Embed user query phrases using a lightweight model and cache.

    This embedder produces deterministic vectors for phrases using a
    placeholder model.  In a production system the embedder would load
    an ONNX version of MiniLM/E5 and run inference on CPU.  To avoid
    repeated computation the embedder uses a two‑tier cache.  Keys are
    derived from the phrase digest plus model identifier and version.
    """

    # Use descriptive identifiers for the embedding model.  When the
    # ONNX model is loaded the version is suffixed with "-onnx" so that
    # cached vectors are invalidated across backends.
    model_id: str = "MiniLM/E5-small"
    model_version: str = "1"

    def __init__(self, cache: Optional[EmbeddingCache] = None) -> None:
        # Expose a shared embedding cache.  If no cache is provided a
        # new two‑tier cache is created.
        self.cache = cache or EmbeddingCache()
        # Attempt to load the ONNX model and tokenizer.  If any step
        # fails (e.g. model files are missing or optional dependencies
        # are not installed), the embedder will revert to a pure
        # hash‑based implementation.  This ensures the library works
        # out of the box without requiring heavy downloads.
        self._use_model = False
        self._session = None  # type: ignore
        self._tokenizer = None  # type: ignore
        if _ort is not None and AutoTokenizer is not None and resolve_model_path is not None:
            try:
                model_dir = resolve_model_path("e5-small")
                model_path = os.path.join(model_dir, "model.onnx")
                if os.path.exists(model_path):
                    self._session = _ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
                    self._tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
                    # Tag version to distinguish ONNX backed vectors
                    self.model_version = "1-onnx"
                    self._use_model = True
            except Exception:
                # Failure to load any component results in fallback mode
                self._session = None
                self._tokenizer = None
                self._use_model = False

    def _compute_vector(self, phrase: str) -> np.ndarray:
        """Compute a vector representation from the phrase.

        When the ONNX model and tokenizer are available this method
        performs real inference using the loaded `onnxruntime` session.
        The resulting tensor is averaged across the token dimension and
        truncated or padded to 16 dimensions to match the previous
        fixed‑length behaviour.  If no model is loaded the function
        derives a deterministic vector from the SHA‑1 digest of the
        phrase.  This fallback maintains deterministic outputs for
        testing and caching purposes.
        """
        if self._use_model and self._session is not None and self._tokenizer is not None:
            try:
                inputs = self._tokenizer(phrase, return_tensors="np", padding=True, truncation=True)
                onnx_inputs = {k: v for k, v in inputs.items()}
                outputs = self._session.run(None, onnx_inputs)
                arr = outputs[0]
                if arr.ndim == 3:
                    vec = arr.mean(axis=1)[0]
                elif arr.ndim == 2:
                    vec = arr[0]
                else:
                    vec = arr.reshape(-1)
                if len(vec) > 16:
                    vec = vec[:16]
                elif len(vec) < 16:
                    vec = np.pad(vec, (0, 16 - len(vec)))
                return vec.astype(np.float32)
            except Exception:
                # Fall through to hash fallback on any inference error
                pass
        digest = sha1_of(phrase)
        return np.array([int(digest[i:i + 2], 16) / 255.0 for i in range(0, 32, 2)], dtype=np.float32)

    def embed(self, phrase: str) -> np.ndarray:
        """Embed a single query phrase into a vector with caching."""
        norm = phrase.strip().lower()
        key = f"{sha1_of(norm)}:{self.model_id}:{self.model_version}"
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        vec = self._compute_vector(norm)
        self.cache.put(key, vec)
        return vec

    def embed_batch(self, phrases: List[str]) -> List[np.ndarray]:
        """Embed a batch of phrases into vectors using the cache."""
        return [self.embed(p) for p in phrases]

    def clear_cache(self) -> None:
        """Clear both the in‑memory and disk caches."""
        self.cache.clear()
