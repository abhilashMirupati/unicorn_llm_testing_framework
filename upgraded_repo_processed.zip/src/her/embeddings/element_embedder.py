"""Element embedder for element descriptors.

This embedder converts element descriptors into dense vectors.  In
production you would use a HTML‑aware model such as MarkupLM.  Here we
generate a deterministic vector from the element's textual representation.
"""

from typing import Any, Dict, List, Optional

import os
import numpy as np

from ..utils import sha1_of
from .cache import EmbeddingCache

# Optional imports for ONNX inference.  If these packages are not
# available at runtime the embedder will gracefully fall back to the
# deterministic hash implementation.  The imports are intentionally
# guarded in a try/except block to avoid import errors during
# installation or when the user has not installed optional ML
# dependencies.
try:
    import onnxruntime as _ort  # type: ignore
    from transformers import AutoTokenizer  # type: ignore
except Exception:
    _ort = None  # type: ignore
    AutoTokenizer = None  # type: ignore

# Lazy import of the model resolver.  The resolver is located in
# ``her.embeddings._resolve`` within the same package.  Importing
# lazily prevents circular dependencies during package initialisation.
try:
    from ._resolve import resolve_model_path  # type: ignore
except Exception:
    resolve_model_path = None  # type: ignore


class ElementEmbedder:
    """Embed element descriptors using a lightweight model and cache.

    This embedder produces deterministic vectors for element descriptors.
    When available it loads an ONNX version of MarkupLM and performs
    inference on CPU to derive semantic embeddings.  To avoid repeated
    computation it leverages a two‑tier cache.  If the ONNX model or
    required dependencies cannot be loaded the embedder falls back to a
    hash‑based representation which preserves determinism for testing
    purposes.
    """

    # Human‑readable identifier for the embedding model.  The
    # ``model_version`` is suffixed with ``-onnx`` when a real model is
    # loaded so that cache entries for the stub and ONNX variants do
    # not collide.
    model_id: str = "MarkupLM"
    model_version: str = "1"

    def __init__(self, cache: Optional[EmbeddingCache] = None) -> None:
        self.cache = cache or EmbeddingCache()
        # Attempt to load the ONNX model and tokenizer.  These fields
        # remain ``None`` if loading fails.  The boolean ``_use_model``
        # indicates whether to attempt inference in ``_compute_vector``.
        self._use_model = False
        self._session = None  # type: ignore
        self._tokenizer = None  # type: ignore
        if _ort is not None and AutoTokenizer is not None and resolve_model_path is not None:
            try:
                model_dir = resolve_model_path("markuplm-base")
                model_path = os.path.join(model_dir, "model.onnx")
                if os.path.exists(model_path):
                    # Load ONNX model into a CPU execution session
                    self._session = _ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
                    # Load the associated tokenizer from the same directory
                    self._tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True)
                    self.model_version = "1-onnx"
                    self._use_model = True
            except Exception:
                # Do not raise if model loading fails; fallback to hash mode
                self._session = None
                self._tokenizer = None
                self._use_model = False

    def _hash_vector(self, element: Dict[str, Any]) -> np.ndarray:
        """Derive a deterministic vector from a dictionary via SHA‑1.

        The element is serialised implicitly via the stable hashing
        function ``sha1_of``.  The resulting digest is chopped into
        eight bytes and normalised to produce a 16‑dimensional vector.
        """
        digest = sha1_of(element)
        vec = np.array([
            int(digest[i : i + 2], 16) / 255.0 for i in range(0, 32, 2)
        ], dtype=np.float32)
        return vec.astype(np.float32)

    def _compute_vector(self, element: Dict[str, Any]) -> np.ndarray:
        """Compute a vector representation from the element descriptor.

        When a real model and tokenizer have been successfully loaded
        ``_use_model`` will be ``True`` and this method runs inference
        using the ONNX session.  The element descriptor is converted
        into a textual representation by concatenating the tag name and
        visible text (if present).  The output tensor is averaged
        across the token dimension and padded or truncated to length 16.
        If inference fails or the model is unavailable the method
        falls back to a deterministic hash‑based vector.
        """
        if self._use_model and self._session is not None and self._tokenizer is not None:
            try:
                # Build a simple textual representation: tag + text + id
                tag = element.get("tag", "")
                text = element.get("text", "") or ""
                elem_id = element.get("id", "") or ""
                phrase = " ".join(filter(None, [str(tag), str(text), str(elem_id)])).strip()
                if not phrase:
                    phrase = str(tag)
                inputs = self._tokenizer(
                    phrase,
                    return_tensors="np",
                    padding=True,
                    truncation=True,
                )
                onnx_inputs = {k: v for k, v in inputs.items()}
                outputs = self._session.run(None, onnx_inputs)
                arr = outputs[0]
                # ONNX outputs [batch_size, seq_len, hidden_dim] or [batch, hidden]
                if arr.ndim == 3:
                    vec = arr.mean(axis=1)[0]
                elif arr.ndim == 2:
                    vec = arr[0]
                else:
                    vec = arr.reshape(-1)
                # Resize to 16 dims
                if len(vec) > 16:
                    vec = vec[:16]
                elif len(vec) < 16:
                    vec = np.pad(vec, (0, 16 - len(vec)))
                return vec.astype(np.float32)
            except Exception:
                # On any failure fallback to hash
                pass
        # Fallback: deterministic vector
        return self._hash_vector(element)

    def embed(self, element: Dict[str, Any]) -> np.ndarray:
        """Embed a single element descriptor into a vector with caching."""
        # Serialise element deterministically via SHA‑1
        digest = sha1_of(element)
        key = f"{digest}:{self.model_id}:{self.model_version}"
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        vec = self._compute_vector(element)
        self.cache.put(key, vec)
        return vec

    def embed_batch(self, elements: List[Dict[str, Any]]) -> List[np.ndarray]:
        """Embed a batch of element descriptors.

        Each element is looked up in the cache if possible.  The order
        of results corresponds to the order of input elements.
        """
        return [self.embed(e) for e in elements]

    def clear_cache(self) -> None:
        """Clear both the in‑memory and on‑disk caches."""
        self.cache.clear()
