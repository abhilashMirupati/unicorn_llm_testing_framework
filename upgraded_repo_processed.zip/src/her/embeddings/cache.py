"""Embedding cache implementation.

This module provides a simple two‑tier cache for embedding vectors.  The
first tier is an in‑memory LRU cache with a configurable capacity.  The
second tier persists vectors on disk using SQLite.  Cached entries are
indexed by a key constructed from the SHA‑1 of the payload (either a
descriptor or a query string) combined with a model identifier and
version.  This ensures that different models or versions do not clash in
the cache.

Vectors are stored as NumPy arrays on disk.  They are serialised to
binary via ``numpy.ndarray.tobytes()`` and deserialised using the shape
recorded in a separate length column.  On retrieval the vector is
reconstructed with dtype ``float32``.

The cache directory defaults to ``.cache/embeddings/`` within the
project root.  You can change this path by passing a different
``db_path`` at construction.
"""

from __future__ import annotations

import os
import sqlite3
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np


@dataclass
class CacheStats:
    hits: int = 0
    misses: int = 0


class EmbeddingCache:
    """Two‑tier cache for embedding vectors.

    The cache maintains an in‑memory LRU dictionary of fixed capacity and
    persists all entries on disk in a SQLite database.  Keys are
    arbitrary strings (typically SHA‑1 digests plus model identifiers).
    Values are NumPy arrays of type ``float32``.  The cache logs hits
    and misses via the ``stats`` attribute.
    """

    def __init__(self, capacity: int = 10_000, db_path: str = ".cache/embeddings/embeddings.db") -> None:
        self.capacity = capacity
        self.memory: "OrderedDict[str, np.ndarray]" = OrderedDict()
        self.stats = CacheStats()
        # Ensure directory exists
        db_file = Path(db_path)
        if not db_file.parent.exists():
            db_file.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(db_file)
        self._init_db()

    def _init_db(self) -> None:
        cur = self.conn.cursor()
        cur.execute(
            "CREATE TABLE IF NOT EXISTS embeddings (\n"
            "  key TEXT PRIMARY KEY,\n"
            "  shape INTEGER,\n"
            "  data BLOB\n"
            ")"
        )
        self.conn.commit()

    def get(self, key: str) -> Optional[np.ndarray]:
        """Retrieve a vector from cache or None if absent.

        Looks up the in‑memory dictionary first; if not found it falls
        back to the SQLite store.  Upon retrieving from disk the entry
        is reinserted into the in‑memory LRU.  The stats counters are
        updated accordingly.
        """
        # Try memory
        if key in self.memory:
            vec = self.memory.pop(key)
            self.memory[key] = vec  # mark as most recently used
            self.stats.hits += 1
            return vec
        # Try disk
        cur = self.conn.cursor()
        cur.execute("SELECT shape, data FROM embeddings WHERE key = ?", (key,))
        row = cur.fetchone()
        if row:
            shape, blob = row
            arr = np.frombuffer(blob, dtype=np.float32)
            arr = arr.reshape((shape,))
            # Insert into memory
            self._put_memory(key, arr)
            self.stats.hits += 1
            return arr
        # Miss
        self.stats.misses += 1
        return None

    def _put_memory(self, key: str, vec: np.ndarray) -> None:
        """Insert vector into LRU memory structure."""
        if key in self.memory:
            # Update existing entry
            self.memory.pop(key)
        elif len(self.memory) >= self.capacity:
            # Evict least recently used
            self.memory.popitem(last=False)
        self.memory[key] = vec

    def put(self, key: str, vec: np.ndarray) -> None:
        """Store a vector in both memory and disk caches."""
        # Memory
        self._put_memory(key, vec)
        # Disk
        cur = self.conn.cursor()
        data = vec.astype(np.float32).tobytes()
        shape = len(vec)
        cur.execute(
            "INSERT OR REPLACE INTO embeddings (key, shape, data) VALUES (?,?,?)",
            (key, shape, data),
        )
        self.conn.commit()

    def clear(self) -> None:
        """Remove all entries from cache and reset stats."""
        self.memory.clear()
        cur = self.conn.cursor()
        cur.execute("DELETE FROM embeddings")
        self.conn.commit()
        self.stats = CacheStats()