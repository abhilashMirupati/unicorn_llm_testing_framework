"""Locator synthesis from ranked candidates.

This module takes ranked candidates and produces a list of concrete
locators.  In a real implementation you might choose between getByRole,
CSS and XPath strategies based on uniqueness and stability.  Here we
return the candidates unchanged for demonstration purposes.

The implementation avoids importing from :mod:`her.cli_api` at module
import time to prevent circular dependencies.  Instead type hints use
forward references and imports guarded by ``typing.TYPE_CHECKING``.
"""

from typing import List, TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    # Only import LocatorCandidate for type checking to avoid circular import
    from ..cli_api import LocatorCandidate


def synthesise_locators(candidates: List["LocatorCandidate"]) -> List["LocatorCandidate"]:
    """Return the locators in the same order as ranked candidates.

    Args:
        candidates: Ranked locator candidates produced by the ranking layer.

    Returns:
        A list of candidates in the same order.  Real implementations
        would adjust the locator format or choose alternative strategies.
    """
    return candidates
