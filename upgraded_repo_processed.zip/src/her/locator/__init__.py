"""Locator synthesis and verification modules."""
