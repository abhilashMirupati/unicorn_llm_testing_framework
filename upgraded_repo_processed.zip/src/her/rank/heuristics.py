"""Heuristic scoring for element candidates.

This module contains functions that assign heuristic scores to elements
based on simple rules, such as whether the tag is a button or link.  In
production these scores would be derived from role/name matching,
placeholder detection and visibility checks.
"""

from typing import Dict, Any


def compute_heuristic_score(phrase: str, element: Dict[str, Any]) -> float:
    """Compute a heuristic score between a phrase and an element.

    The current implementation rewards button elements for phrases
    containing the word "button" and returns a small constant otherwise.
    """
    if "button" in phrase and element.get("tag") == "button":
        return 0.8
    return 0.5
