"""Self‑healing and promotion subsystems."""
