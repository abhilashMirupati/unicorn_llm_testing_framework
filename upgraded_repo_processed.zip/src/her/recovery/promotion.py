"""Locator promotion logic.

The promotion component would record successful locators and boost their
ranking on subsequent runs.  The current implementation provides a
placeholder function.
"""

from typing import Any


def promote_locator(locator: Any) -> None:
    """Record the successful locator for future runs (no‑op)."""
    return None
