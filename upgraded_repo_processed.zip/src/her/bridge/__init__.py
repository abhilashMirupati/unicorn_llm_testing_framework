"""Bridges for interacting with browser and accessibility layers."""
