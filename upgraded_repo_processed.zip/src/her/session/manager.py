"""Session manager responsible for navigation and automatic indexing.

This module defines the :class:`SessionManager` which wraps a Playwright
browser and page instance and coordinates navigation and automatic
snapshotting/indexing of the current DOM.  The session manager maintains
an internal cache keyed by the origin, frame path and DOM hash.  When
navigating to a new URL or when the DOM structure changes beyond a
threshold, a fresh snapshot is captured and element descriptors are
embedded.  Consumers of this class (e.g. :class:`HybridClient`) rely
exclusively on its high‑level API and must not call lower‑level index
functions directly.

The default behaviour is "auto‑index" – callers never need to invoke
``index()`` manually.  When ``auto_index`` is disabled via the
configuration, callers may still force a snapshot via ``snapshot_and_index``.

This implementation uses Playwright synchronously.  It launches a
headless Chromium instance on first use and reuses a single page for
subsequent navigations.  The real CDP snapshotting is delegated to
``bridge.snapshot.capture_snapshot()`` which returns element descriptors
and a DOM hash.  A naive delta check based on hash equality triggers
re‑indexing when needed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

try:
    # Import Playwright classes when available.  If Playwright is not installed
    # the import will fail and the variables are assigned sentinel values so
    # that the rest of the code can detect the absence of the dependency and
    # operate in a stub mode.  See :meth:`_ensure_browser` for usage.
    from playwright.sync_api import Playwright, sync_playwright, Page  # type: ignore
except Exception:  # pragma: no cover - fallback when Playwright is not installed
    Playwright = None  # type: ignore[misc]
    sync_playwright = None  # type: ignore[misc]
    Page = Any  # type: ignore

from ..config import HERConfig
from ..bridge.snapshot import capture_snapshot


@dataclass
class PageInfo:
    """Simple container for page metadata used by the session manager."""

    url: str
    dom_hash: str
    framePath: str


class SessionManager:
    """Manage a Playwright session and automatic DOM indexing.

    The session manager owns the browser context and page.  It is
    responsible for loading URLs, capturing DOM snapshots, maintaining
    caches and exposing the current set of element descriptors.  All
    indexing happens automatically when navigating or when the DOM
    structure changes.  Consumers must not call low‑level indexing
    functions; the manager orchestrates everything based on
    configuration.
    """

    def __init__(self, config: HERConfig) -> None:
        self.config = config
        self._playwright: Optional[Playwright] = None
        self._browser = None
        self._page: Optional[Page] = None
        # Cache mapping (origin, framePath, dom_hash) → list of descriptors
        self.cache: Dict[str, List[Dict[str, Any]]] = {}
        # Current page metadata
        self.current_page: Optional[PageInfo] = None
        # Current descriptors and hash
        self._descriptors: List[Dict[str, Any]] = []

    def _ensure_browser(self) -> None:
        """Ensure a Playwright browser and page exist.

        If Playwright cannot be started (for example, when the optional
        dependency is not installed or a browser cannot be launched) the
        manager gracefully falls back to a stub mode in which no page is
        available.  In stub mode the snapshotting functions will return an
        empty descriptor list and a deterministic DOM hash.
        """
        if self._playwright is None:
            # If the optional Playwright dependency is unavailable the
            # sync_playwright entry point will be ``None`` and we cannot
            # attempt to start a browser.  In such cases we simply leave
            # the internal browser and page references as ``None`` and
            # rely on downstream functions (e.g. ``capture_snapshot``) to
            # handle the ``None`` page gracefully.
            if sync_playwright is None:
                self._playwright = None
                self._browser = None
                self._page = None
                return
            try:
                self._playwright = sync_playwright().start()
                # Launch a headless Chromium browser once
                self._browser = self._playwright.chromium.launch(headless=True)
                self._page = self._browser.new_page()
            except Exception:
                # Playwright could not be started; operate in stub mode
                self._playwright = None
                self._browser = None
                self._page = None

    def _snapshot_if_needed(self, url: str) -> Tuple[str, str]:
        """Navigate to the URL if needed and capture a snapshot.

        Returns a tuple (dom_hash, framePath).
        """
        self._ensure_browser()
        # Navigate if we have a real page and the URL has changed.
        if self._page is not None:
            if self.current_page is None or self.current_page.url != url:
                try:
                    self._page.goto(url)
                except Exception:
                    # ignore navigation errors; fall back to stub
                    self._page = None
        # Capture snapshot.  If we have a page use it; otherwise pass None to
        # capture_snapshot which will return an empty list.
        try:
            result = capture_snapshot(
                self._page,  # type: ignore[arg-type]
                frame_path="main",
                dom_max_wait_ms=self.config.dom_max_wait_ms,
                network_idle_ms=self.config.network_idle_ms,
                ax_presence_timeout_ms=self.config.ax_presence_timeout_ms,
            )
        except Exception:
            # On any error fallback to empty descriptors and compute a deterministic hash
            result = []
        # Normalise the return: capture_snapshot returns [] when no page is
        # provided, otherwise a tuple (descriptors, dom_hash).
        if isinstance(result, tuple):
            descriptors, dom_hash = result
        else:
            descriptors = []
            # Derive a deterministic hash for an empty snapshot.  Incorporate
            # the URL into the hash so that different pages yield different
            # values even when no DOM is available (e.g. stub mode).
            from ..utils import sha1_of  # imported here to avoid circular import

            dom_hash = sha1_of(url)
        # Determine if indexing needed
        need_index = False
        if self.current_page is None:
            need_index = True
        else:
            # Compare DOM hashes
            prev_hash = self.current_page.dom_hash
            # Compute simple delta: if hashes differ, treat as changed
            need_index = dom_hash != prev_hash
        # Update current page info and descriptors
        self.current_page = PageInfo(url=url, dom_hash=dom_hash, framePath="main")
        if need_index:
            # Store descriptors in cache and update current descriptors
            cache_key = f"{url}|main|{dom_hash}"
            self.cache[cache_key] = descriptors
            self._descriptors = descriptors
        return dom_hash, "main"

    def ensure_page(self, url: Optional[str]) -> Dict[str, str]:
        """Ensure a page is loaded and indexed.

        This method is idempotent: if ``url`` is ``None`` it returns
        information about the currently loaded page.  If a new URL is
        provided it navigates to that URL, captures a snapshot and indexes
        elements as needed.  The caller receives the current DOM hash and
        frame path.

        Args:
            url: The URL to navigate to.  If ``None`` the current page
                information is returned.

        Returns:
            A dictionary with keys ``dom_hash`` and ``framePath``.
        """
        if url is None:
            if self.current_page is None:
                # Nothing loaded yet → load blank page
                url = "about:blank"
            else:
                return {
                    "dom_hash": self.current_page.dom_hash,
                    "framePath": self.current_page.framePath,
                }
        # Navigate and snapshot if needed
        dom_hash, framePath = self._snapshot_if_needed(url)
        return {"dom_hash": dom_hash, "framePath": framePath}

    def get_elements(self) -> List[Dict[str, Any]]:
        """Return the current list of element descriptors.

        The descriptors are the result of the most recent snapshot and index.
        If no descriptors are available an empty list is returned.
        """
        return list(self._descriptors)

    def snapshot_and_index(self, url: Optional[str] = None) -> None:
        """Force a fresh snapshot and index of the current or given page.

        If ``url`` is provided the page will be navigated to that URL; if
        omitted the current page URL is used.  The resulting descriptors
        replace any cached entries for the old DOM hash.
        """
        if url is None and self.current_page is not None:
            url = self.current_page.url
        elif url is None:
            url = "about:blank"
        # Invalidate current cache entry
        if self.current_page:
            old_key = f"{self.current_page.url}|{self.current_page.framePath}|{self.current_page.dom_hash}"
            self.cache.pop(old_key, None)
        # Navigate and force snapshot
        self._ensure_browser()
        # If we have a real page navigate to the URL; otherwise operate in stub mode
        if self._page is not None:
            try:
                self._page.goto(url)
            except Exception:
                self._page = None
        try:
            result = capture_snapshot(
                self._page,  # type: ignore[arg-type]
                frame_path="main",
                dom_max_wait_ms=self.config.dom_max_wait_ms,
                network_idle_ms=self.config.network_idle_ms,
                ax_presence_timeout_ms=self.config.ax_presence_timeout_ms,
            )
        except Exception:
            result = []
        if isinstance(result, tuple):
            descriptors, dom_hash = result
        else:
            descriptors = []
            from ..utils import sha1_of  # imported here to avoid circular import

            # Derive a deterministic hash that incorporates the URL so that
            # different pages yield distinct hashes even when no snapshot is
            # available (stub mode).
            dom_hash = sha1_of(url)
        self.current_page = PageInfo(url=url, dom_hash=dom_hash, framePath="main")
        cache_key = f"{url}|main|{dom_hash}"
        self.cache[cache_key] = descriptors
        self._descriptors = descriptors
