"""Public Python API for the Hybrid Element Retriever.

The :class:`HybridClient` class wraps the underlying session, parser, retrieval
and execution logic.  Users should interact exclusively with this class
instead of calling internal modules directly.  Manual indexing is supported
only for power users; the default behaviour is to index automatically when
necessary.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import List, Optional, Dict, Any

from .config import HERConfig, DEFAULT_CONFIG
from .parser.intent import parse_intent
from .session.manager import SessionManager
from .embeddings.query_embedder import QueryEmbedder
from .embeddings.element_embedder import ElementEmbedder
from .rank.fusion import rank_candidates
from .executor.actions import perform_action
from .locator.synthesize import synthesise_locators


@dataclass
class LocatorCandidate:
    """A candidate locator returned by the retrieval process.

    Attributes:
        type: The locator type (e.g. 'css', 'xpath', 'role').
        selector: The raw selector string.
        score: A semantic score in the range [0, 1].
        stability: A rough measure of how stable the locator is.
        rationale: Free text explaining why this locator was chosen.
    """

    type: str
    selector: str
    score: float
    stability: float
    rationale: str


class HybridClient:
    """Primary entry point for HER clients.

    The client maintains a :class:`SessionManager` to handle page navigation
    and automatic indexing.  It exposes two main methods:

    * :meth:`act` executes a plain English instruction on a page.
    * :meth:`query` returns ranked locator candidates for a phrase.

    Parameters:
        config: Optional configuration to override defaults.

    Note:
        Passing ``auto_index=False`` will disable the automatic indexing
        behaviour.  This is meant for advanced users only.
    """

    def __init__(self, config: Optional[HERConfig] = None) -> None:
        self.config = config or DEFAULT_CONFIG
        self.session_manager = SessionManager(config=self.config)
        # Embedders would normally load heavy models here.  We stub them
        # with simple implementations.
        self.query_embedder = QueryEmbedder()
        self.element_embedder = ElementEmbedder()

    def act(self, step: str, url: Optional[str] = None) -> Dict[str, Any]:
        """Execute a natural language step on a web page.

        Args:
            step: The plain English instruction to interpret (e.g. "Click
                the login button").
            url: An optional URL to navigate to before executing the step.

        Returns:
            A JSON-serialisable dictionary describing the outcome.  This
            includes the selected locator, confidence score, whether any
            self‑healing was required and other diagnostic information.
        """
        # Navigate and index as needed
        page_info = self.session_manager.ensure_page(url)

        # Parse the intent
        intent = parse_intent(step)

        # Retrieve candidates
        candidates = self.query(intent.target_phrase, url=url)
        if not candidates:
            return {
                "status": "fail",
                "method": "cache",
                "confidence": 0.0,
                "dom_hash": page_info.get("dom_hash"),
                "framePath": page_info.get("framePath"),
                "semantic_locator": None,
                "used_locator": None,
                "n_best": [],
                "overlay_events": [],
                "retries": {"attempts": 0, "final_method": "none"},
                "explanation": "No candidates found for phrase",
            }

        # Synthesis and selection: pick the top candidate
        locators = synthesise_locators(candidates)
        chosen = locators[0] if locators else None

        # Perform action – stubbed for demonstration
        action_result = perform_action(intent.action, chosen)

        # Compose response
        return {
            "status": "ok" if action_result.get("ok") else "fail",
            "method": "cache",  # assume cache for stub
            "confidence": candidates[0].score,
            "dom_hash": page_info.get("dom_hash"),
            "framePath": page_info.get("framePath"),
            "semantic_locator": f"{{role '{intent.target_phrase}'}}",
            "used_locator": chosen.selector if chosen else None,
            "n_best": [c.__dict__ for c in candidates],
            "overlay_events": [],
            "retries": {"attempts": 1, "final_method": "cache"},
            "explanation": action_result.get("explanation", "Performed action"),
        }

    def query(self, phrase: str, url: Optional[str] = None) -> List[LocatorCandidate]:
        """Retrieve ranked locator candidates for a phrase.

        Args:
            phrase: The user‑provided phrase describing the element (e.g.
                "Submit button").
            url: Optional URL of the page; if provided, the page will be
                navigated to and indexed automatically.

        Returns:
            A list of :class:`LocatorCandidate` objects sorted by descending
            relevance.
        """
        page_info = self.session_manager.ensure_page(url)

        # In a real implementation the session manager would return an
        # up‑to‑date element inventory.  We stub it here with an empty list.
        elements = self.session_manager.get_elements()

        # Compute embeddings (stubbed) and rank candidates
        query_vec = self.query_embedder.embed(phrase)
        element_vecs = self.element_embedder.embed_batch(elements)
        ranked = rank_candidates(phrase, elements, query_vec, element_vecs, self.config)

        # Convert to LocatorCandidate objects
        return [
            LocatorCandidate(
                type=c["type"],
                selector=c["selector"],
                score=c["score"],
                stability=c.get("stability", 0.0),
                rationale=c.get("rationale", "")
            )
            for c in ranked
        ]

    # Manual index for advanced users
    def index(self, url: Optional[str] = None) -> None:
        """Force a fresh snapshot and index of the current page.

        This method is intended for power users only.  Normal tests should
        rely on automatic indexing triggered by :meth:`act` and
        :meth:`query`.  Calling this method will refresh the element
        inventory and invalidate any cached embeddings.
        """
        self.session_manager.snapshot_and_index(url)
