# Self‑Critique: Pre‑Upgrade Audit (2025‑08‑27)

This document records the findings of the automated auditor before any
modifications were applied to the uploaded repository.  The goal of
this pass is to identify gaps, broken imports, placeholders and other
risks that must be addressed to produce a production‑ready release of
the Hybrid Element Retriever (HER).

## Summary of Findings

The repository contains a largely functional stub implementation of
HER.  The code is well organised and includes modules for session
management, embedding, ranking, locator synthesis, execution, recovery
and configuration.  There is an extensive CHANGELOG and risk register
and a reasonably comprehensive CI pipeline.  However, several issues
were identified during the audit that prevent the project from
operating correctly in minimal environments and hinder test coverage.

## Issues Detected

| Area | Finding | Severity | Evidence |
| --- | --- | --- | --- |
| **Playwright import** | The session manager and bridge modules import `playwright.sync_api` unconditionally.  When Playwright is not installed (e.g. in a minimal container) these imports raise a `ModuleNotFoundError`, causing the entire package to fail to import. | ⚠️ Medium | `src/her/session/manager.py` and `src/her/bridge/snapshot.py` import `playwright.sync_api.Page` directly. |
| **Circular import** | `her/cli_api.py` imports `synthesise_locators` from `her/locator/synthesize.py`.  That module imports `LocatorCandidate` from `cli_api` for type annotations.  Python resolves modules eagerly and hits a circular dependency, leading to `ImportError: cannot import name 'LocatorCandidate' from partially initialized module 'her.cli_api'` when tests import `HybridClient`. | ❌ High | Running `tests/test_e2e_demo.py` results in an `ImportError` at import time. |
| **Deterministic DOM hash** | In stub mode the session manager always computes the same DOM hash (`sha1_of(())`) regardless of the URL.  As a result, tests that rely on different pages producing different hashes fail.  A deterministic but URL‑specific hash is needed when no real snapshot is available. | ❌ High | `test_session_auto_index.py` asserts that navigating to two different URLs yields different `dom_hash` values. |
| **Incomplete coverage** | The existing test suite exercises only a subset of the codebase.  Modules such as the embedding cache, vector store, heuristic scoring variations and various utility functions are never executed.  A quick coverage estimation shows roughly 30–40 % of lines executed. | ⚠️ Low | Manual `trace`‑based coverage analysis indicates ~31 % line coverage. |
| **pytest import** | Some test files import `pytest` merely to make assertions or for docstrings.  The project does not include `pytest` as a required dependency, so these imports fail in environments without the library.  Although the tests do not use any `pytest` features, the import should be removed or guarded. | ⚠️ Low | `tests/test_json_contract.py` and `tests/test_zero_index_flow.py` import `pytest` but never call it. |

### Additional Observations

* **Session fallback:** The session manager does attempt to fall back to a stub
  mode when Playwright fails to launch, but it does not guard against
  the initial import failure.  As a result, simply importing the module
  fails before any fallback logic can be invoked.
* **Hash collisions:** Returning the same DOM hash for all stub pages
  prevents the cache from distinguishing between pages.  A simple fix
  is to incorporate the URL string into the hash when no snapshot is
  captured.
* **Test extensions:** To reach the mandated coverage threshold and
  ensure behavioural correctness across modules, additional tests are
  needed to drive execution through untested functions such as the
  embedding cache, vector store and secondary code paths in the
  ranking and utilities modules.

## Import Graph Risks

The most significant import‑time risk is the circular dependency between
`cli_api` and `locator.synthesize`.  In Python, import cycles are
particularly fragile because modules execute top‑level code during
import.  Type annotations should use forward references or guard
imports behind `typing.TYPE_CHECKING` to avoid pulling in heavy
dependencies at module import time.

Another import‑time risk is the unconditional import of optional
dependencies.  The CDP bridge and session manager should wrap
`playwright` imports in `try/except` blocks and substitute type
aliases or `Any` when Playwright is absent.

## Recommended Remediations

The following concrete actions are proposed:

1. **Guard Playwright imports** – wrap `from playwright.sync_api import ...` in
   `try/except` and set sentinel values when missing.  Adjust
   `_ensure_browser` to check for a missing `sync_playwright` and fall
   back gracefully.
2. **Resolve circular import** – modify `her/locator/synthesize.py` to
   avoid importing `LocatorCandidate` from `cli_api` at module import
   time.  Use forward references (`"LocatorCandidate"`) and guard the
   import under `typing.TYPE_CHECKING`.
3. **Improve stub DOM hash** – when the snapshot function returns an
   empty list (i.e. no page is available), derive a deterministic hash
   that incorporates the URL so that different pages produce distinct
   values.
4. **Eliminate unnecessary pytest dependency** – remove or guard
   spurious `pytest` imports in tests.  Alternatively, provide a
   minimal `pytest` stub during testing to prevent import errors.
5. **Expand test coverage** – add a new test module exercising the
   embedding cache, vector store, heuristic functions, additional
   intents and session flows.  This will increase coverage towards the
   80 % target without resorting to unrealistic instrumentation.

This self‑critique sets the stage for the subsequent implementation and
iteration phases.  Each identified issue feeds into the TODO list and
will be addressed in the following steps.