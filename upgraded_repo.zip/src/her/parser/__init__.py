"""Parser subpackage.

The parser is responsible for extracting structured intent from natural
language steps.  See :mod:`intent` for details.
"""
