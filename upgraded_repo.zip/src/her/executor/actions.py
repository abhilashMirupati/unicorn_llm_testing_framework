"""Perform actions on the web page.

In production this module would use Playwright's API to click, type,
select or otherwise manipulate elements.  Here we simulate success or
failure based on the action name and provided locator.
"""

from typing import Any, Dict


def perform_action(action: str, locator: Any) -> Dict[str, Any]:
    """Simulate performing the given action on the element.

    Args:
        action: The name of the action (e.g. ``click`` or ``type``).
        locator: A locator candidate chosen by the synthesis step.  In the
            stub implementation this is ignored.

    Returns:
        A dictionary with at least an ``ok`` boolean and an
        ``explanation`` string.
    """
    if locator is None:
        return {"ok": False, "explanation": "No locator provided"}
    # Simulate always successful action
    return {"ok": True, "explanation": f"{action} executed"}
