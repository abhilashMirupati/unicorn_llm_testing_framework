"""Command‑line interface for the Hybrid Element Retriever.

The CLI entry point is invoked by running ``python -m her.cli``.  It
parses command line arguments and delegates to the :class:`HybridClient`.
All indexing is automatic; manual indexing is not exposed via the CLI.
"""

import argparse
import json
from typing import Optional

from .cli_api import HybridClient


def _setup_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="her", description="Hybrid Element Retriever CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # 'act' command
    act_parser = subparsers.add_parser("act", help="Perform an action on the page")
    act_parser.add_argument("--url", required=True, help="The URL of the page to open")
    act_parser.add_argument("--step", required=True, help="The plain English step to execute")

    # 'query' command
    query_parser = subparsers.add_parser("query", help="Retrieve candidate locators for a phrase")
    query_parser.add_argument("phrase", help="The target phrase to search for")
    query_parser.add_argument("--url", help="Optional URL of the page")

    # 'cache' command
    cache_parser = subparsers.add_parser("cache", help="Manage embedding cache")
    cache_parser.add_argument(
        "--clear",
        action="store_true",
        help="Clear the on‑disk and in‑memory embedding cache",
    )

    return parser


def main(argv: Optional[list[str]] = None) -> None:
    parser = _setup_parser()
    args = parser.parse_args(argv)

    client = HybridClient()

    if args.command == "act":
        result = client.act(step=args.step, url=args.url)
        print(json.dumps(result, indent=2))
    elif args.command == "query":
        candidates = client.query(phrase=args.phrase, url=args.url)
        # Convert dataclasses to dicts for JSON serialisation
        data = [c.__dict__ for c in candidates]
        print(json.dumps(data, indent=2))
    elif args.command == "cache":
        # manage embedding cache
        if args.clear:
            # Clear caches on both embedder instances
            client.query_embedder.clear_cache()
            client.element_embedder.clear_cache()
            print(json.dumps({"cleared": True}))
        else:
            print(json.dumps({"cleared": False}))


if __name__ == "__main__":  # pragma: no cover
    main()
