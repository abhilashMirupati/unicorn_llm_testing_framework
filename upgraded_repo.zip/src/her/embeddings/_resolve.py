"""Utility functions for resolving model paths.

This module defines helper functions to locate ONNX model directories
packaged with HER or installed by the user.  The resolver follows a
simple priority order:

1. The environment variable ``HER_MODELS_DIR`` can be set to an absolute
   path.  If that directory contains a subdirectory matching the
   requested model (e.g. ``e5-small`` or ``markuplm-base``) it is
   returned.
2. If the package bundles models under ``her.models/<subdir>`` (for
   example when distributed via PyPI) this location will be returned.
3. A user-level cache under ``~/.her/models/<subdir>`` is used as a
   fallback.  This allows models to be shared across virtual
   environments.

If none of these locations contain the requested model a
``FileNotFoundError`` is raised with a helpful message.  Consumers of
this function should catch the exception and fall back to a stub
implementation if necessary.
"""

from __future__ import annotations

import os
from pathlib import Path
from importlib.resources import files
from typing import Optional


def resolve_model_path(subdir: str) -> str:
    """Resolve the filesystem path of an ONNX model directory.

    This helper searches for the requested subdirectory in a set of
    predefined locations.  The order of precedence is:

    1. The directory specified by the ``HER_MODELS_DIR`` environment
       variable.
    2. A packaged resource under ``her.models/<subdir>`` (requires
       ``importlib.resources`` to find data files within the installed
       package).
    3. A user cache at ``~/.her/models/<subdir>``.

    Args:
        subdir: The name of the model subdirectory to resolve (e.g.
            ``"e5-small"`` or ``"markuplm-base"``).

    Returns:
        The absolute path to the model directory.

    Raises:
        FileNotFoundError: If the model directory cannot be found in any
            of the expected locations.
    """
    # 1) Environment override
    env_dir = os.getenv("HER_MODELS_DIR")
    if env_dir:
        candidate = Path(env_dir) / subdir
        if candidate.exists():
            return str(candidate)

    # 2) Packaged resources
    try:
        res = files("her.models") / subdir
        if res.is_dir():
            return str(res)
    except Exception:
        # If importlib.resources cannot find the package or resource,
        # ignore and fall through to the next option.
        pass

    # 3) User-level cache
    home_candidate = Path.home() / ".her" / "models" / subdir
    if home_candidate.exists():
        return str(home_candidate)

    # None of the locations exist → raise a helpful error
    raise FileNotFoundError(
        f"HER model directory not found for '{subdir}'. "
        "Run scripts/install_models.(sh|ps1) or set HER_MODELS_DIR."
    )